# KisanPulse AI — Smart Agriculture & Rural Development

> A cutting-edge, mobile-first AI agriculture platform empowering Indian farmers with real-time APMC Mandi pricing, AI crop health diagnostics, and personalized Government Scheme matching.

---

## Architecture & Integration Shell

This repository provides the core foundation shell for KisanPulse AI built with React, Vite, and an agriculture-themed design system.

### Features
1. **Smart Mandi & Farm Profit Engine**: Real-time commodity tracking across regional APMC markets, MSP differentials, and live net farm profit & margin calculator.
2. **Crop Health & Smart Farming**: Integrated via `src/modules/farming/FarmingModule.jsx` with crash isolation and placeholder fallback.
3. **Government SchemeMatch**: Integrated via `src/modules/schemes/SchemeModule.jsx` with subsidy matching and checklist guidance.
4. **Bilingual Support (Hindi / English)**: Full language toggle backed by `localStorage` persistence.
5. **Offline Resilient**: Connectivity monitor, cached data warning banners, and simulated demo toggles.
6. **Shared Component System**: Resilient Button, Card, Loading, Error, EmptyState, and ErrorBoundary components.

---

## Getting Started

### Prerequisites
- Node.js (v18+)
- npm (v9+)

### Installation
```bash
git clone <repo-url>
cd kisanpulse-ai
npm install
```

### Development Server
```bash
npm run dev
```

### Production Build
```bash
npm run build
```

---

## Integration Contract for Teammates

Teammates working on **Farming** and **Schemes** should develop under:
- `src/modules/farming/FarmingModule.jsx`
- `src/modules/schemes/SchemeModule.jsx`

Each module should export one default React component:
```jsx
export default function FarmingModule({ language, isOffline, t, navigate }) {
  return (
    <div className="kp-module-content">
      {/* Module UI */}
    </div>
  );
}
```
The application shell automatically resolves and mounts these components once merged into the project tree.
