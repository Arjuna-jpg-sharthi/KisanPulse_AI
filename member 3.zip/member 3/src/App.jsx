import React from 'react'
import SchemeModule from './modules/schemes/SchemeModule'

function App() {
  return (
    <div className="app">
      <SchemeModule />
    </div>
  )
}

export default App
