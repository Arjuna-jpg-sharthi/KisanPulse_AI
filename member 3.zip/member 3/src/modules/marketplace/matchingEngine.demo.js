/**
 * matchingEngine.demo.js — KisanPulse AI Matching Engine demo / smoke test
 *
 * Run:  node src/modules/marketplace/matchingEngine.demo.js
 *
 * This file demonstrates both exported functions with realistic Indian
 * agriculture data and prints the results to stdout.
 */

// ESM import (project is "type": "module" in package.json)
import { rankMatches, calculateDealComparison } from './matchingEngine.js';

// ═══════════════════════════════════════════════════════════════════════════
// Demo 1 — rankMatches
// ═══════════════════════════════════════════════════════════════════════════

const farmerListings = [
  {
    id: 'F001',
    crop: 'Wheat',
    variety: 'HD-2967',
    quantityQuintals: 50,
    harvestDate: '2026-11-15',
    expectedPricePerQuintal: 2200,
    district: 'Indore',
    state: 'Madhya Pradesh',
    grade: 'A',
    moisture: 12,
  },
  {
    id: 'F002',
    crop: 'Soybean',
    variety: 'JS-9560',
    quantityQuintals: 30,
    harvestDate: '2026-10-25',
    expectedPricePerQuintal: 4500,
    district: 'Dewas',
    state: 'Madhya Pradesh',
  },
  {
    id: 'F003',
    crop: 'Wheat',
    variety: 'Lokwan',
    quantityQuintals: 20,
    harvestDate: '2026-11-20',
    expectedPricePerQuintal: 2350,
    district: 'Ujjain',
    state: 'Madhya Pradesh',
  },
];

const buyerRequests = [
  {
    id: 'B001',
    crop: 'Wheat',
    quantityQuintals: 40,
    maxPricePerQuintal: 2300,
    neededBy: '2026-11-30',
    district: 'Indore',
    state: 'Madhya Pradesh',
  },
  {
    id: 'B002',
    crop: 'Soybean',
    quantityQuintals: 50,
    maxPricePerQuintal: 4400,
    neededBy: '2026-11-01',
    district: 'Bhopal',
    state: 'Madhya Pradesh',
  },
  {
    id: 'B003',
    crop: 'Rice',
    quantityQuintals: 100,
    maxPricePerQuintal: 2000,
    neededBy: '2026-12-01',
    district: 'Raipur',
    state: 'Chhattisgarh',
  },
];

console.log('══════════════════════════════════════════════════════');
console.log('  DEMO 1 — rankMatches');
console.log('══════════════════════════════════════════════════════\n');

const { matches, validationErrors } = rankMatches(farmerListings, buyerRequests);

if (validationErrors.length > 0) {
  console.log('Validation errors:');
  console.log(JSON.stringify(validationErrors, null, 2));
}

console.log(`Found ${matches.length} match(es):\n`);

for (const m of matches) {
  console.log(`--- Farmer ${m.farmerListing.id} × Buyer ${m.buyerRequest.id} ---`);
  console.log(`  Crop:    ${m.farmerListing.crop}`);
  console.log(`  Score:   ${m.score} / 100`);
  console.log(`  Status:  ${m.compatibilityStatus}`);
  console.log('  Reasons:');
  for (const r of m.reasons) {
    console.log(`    • ${r}`);
  }
  console.log();
}

/*
 * ── Expected output (approximate) ──
 *
 * Match F001 × B001 — Wheat, same district (Indore), buyer max ₹2300 ≥ farmer ask ₹2200,
 *   quantity 50 available / 40 needed (full), harvest 2026-11-15 before deadline 2026-11-30.
 *   → Score ~100 (Excellent)
 *
 * Match F003 × B001 — Wheat, same state but different districts (Ujjain → Indore),
 *   quantity 20/40 = partial (50%), price ₹2350 vs max ₹2300 (buyer below ask),
 *   harvest 2026-11-20 before deadline 2026-11-30.
 *   → Score ~54 (Fair)
 *
 * Match F002 × B002 — Soybean, same state diff districts (Dewas → Bhopal),
 *   quantity 30/50 = partial (60%), price ₹4500 vs max ₹4400 (buyer below ask),
 *   harvest 2026-10-25 before deadline 2026-11-01.
 *   → Score ~58 (Fair)
 *
 * No Rice listings → B003 has no matches.
 */

// ═══════════════════════════════════════════════════════════════════════════
// Demo 2 — calculateDealComparison
// ═══════════════════════════════════════════════════════════════════════════

console.log('\n══════════════════════════════════════════════════════');
console.log('  DEMO 2 — calculateDealComparison');
console.log('══════════════════════════════════════════════════════\n');

const comparison = calculateDealComparison({
  listing: farmerListings[0],
  offerPricePerQuintal: 2300,
  mandiPricePerQuintal: 2250,
  quantityQuintals: 40,
  costs: {
    transport: 3000,
    loadingHandling: 800,
    mandiFeePercent: 1,     // 1 % of mandi gross
    cessPercent: 0.5,       // 0.5 % cess
    commissionPercent: 2.5, // 2.5 % commission — EXPLICITLY supplied for demo
  },
});

console.log(JSON.stringify(comparison, null, 2));

/*
 * ── Expected output (exact) ──
 *
 * Direct sale:
 *   Gross  = 2300 × 40 = ₹92,000
 *   Costs  = transport ₹3,000 + loading ₹800 = ₹3,800
 *   Net    = ₹88,200
 *
 * Mandi sale:
 *   Gross  = 2250 × 40 = ₹90,000
 *   Costs  = transport ₹3,000 + loading ₹800
 *          + mandi fee 1% of 90,000 = ₹900
 *          + cess 0.5% of 90,000 = ₹450
 *          + commission 2.5% of 90,000 = ₹2,250
 *          = ₹7,400
 *   Net    = ₹82,600
 *
 * Difference: ₹88,200 − ₹82,600 = ₹5,600 in favour of Direct Sale
 * Commission savings note explains the ₹2,250 commission is based on
 * the 2.5% rate the user supplied.
 */

// ═══════════════════════════════════════════════════════════════════════════
// Demo 3 — Validation edge cases
// ═══════════════════════════════════════════════════════════════════════════

console.log('\n══════════════════════════════════════════════════════');
console.log('  DEMO 3 — Validation edge cases');
console.log('══════════════════════════════════════════════════════\n');

// 3a: Invalid listing (negative quantity)
const badResult = rankMatches(
  [{ id: 'BAD1', crop: 'Wheat', quantityQuintals: -5, expectedPricePerQuintal: 2000, district: 'Indore', state: 'MP' }],
  buyerRequests,
);
console.log('3a — Invalid listing errors:', JSON.stringify(badResult.validationErrors, null, 2));

// 3b: Deal comparison with missing price
const badDeal = calculateDealComparison({
  offerPricePerQuintal: 0,
  mandiPricePerQuintal: 2000,
  quantityQuintals: 10,
});
console.log('\n3b — Invalid deal comparison:', JSON.stringify(badDeal, null, 2));

// 3c: Deal comparison with no commission (no savings note)
const noCommDeal = calculateDealComparison({
  listing: farmerListings[0],
  offerPricePerQuintal: 2200,
  mandiPricePerQuintal: 2200,
  quantityQuintals: 50,
  costs: { transport: 2000 },
});
console.log('\n3c — No commission supplied → commissionSavingsNote is null:');
console.log('  commissionSavingsNote:', noCommDeal.comparison.commissionSavingsNote);
console.log('  Direct net:', noCommDeal.directSale.estimatedNetProceeds);
console.log('  Mandi net: ', noCommDeal.mandiSale.estimatedNetProceeds);
