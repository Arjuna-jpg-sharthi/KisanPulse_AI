# Marketplace Matching Engine — KisanPulse AI

> **Module path:** `src/modules/marketplace/matchingEngine.js`
> **Branch:** `feature/matching-engine`
> **Dependencies:** None (pure JS, deterministic)

---

## Exported Functions

### 1. `rankMatches(farmerListings, buyerRequests)`

Matches farmer crop listings against buyer purchase requests. Only pairs with the **same crop** (case-insensitive) are considered valid matches.

#### Parameters

| Parameter | Type | Description |
|---|---|---|
| `farmerListings` | `Object[]` | Array of farmer listing objects |
| `buyerRequests` | `Object[]` | Array of buyer request objects |

#### Returns

```js
{
  matches: [
    {
      farmerListing,        // original farmer post
      buyerRequest,         // original buyer request
      score,                // 0–100
      compatibilityStatus,  // 'Excellent' | 'Good' | 'Fair' | 'Poor'
      reasons,              // string[] — one human-readable reason per dimension
    }
  ],
  validationErrors: [...]   // any skipped records with reasons
}
```

#### Scoring Weights (total = 100)

| Dimension | Weight | Logic |
|---|---|---|
| **Price** | 35 | Full if buyer max ≥ farmer ask; otherwise proportional (`offer / ask`) |
| **Quantity** | 25 | Full if farmer can fill order; partial matches are proportional **and explicitly flagged** with remaining quantity |
| **Location** | 25 | Same district → 25; same state, different district → 15; different states → 0 |
| **Date** | 15 | Harvest on/before deadline → 15; up to 30 days late → linear decay; >30 days → 0; missing dates → 7 |

#### Compatibility Status Thresholds

| Score Range | Status |
|---|---|
| 80–100 | Excellent |
| 60–79 | Good |
| 40–59 | Fair |
| 0–39 | Poor |

---

### 2. `calculateDealComparison({ listing, offerPricePerQuintal, mandiPricePerQuintal, quantityQuintals, costs })`

Compares selling directly to a buyer versus selling through a mandi (APMC market).

#### Parameters

| Parameter | Type | Required | Description |
|---|---|---|---|
| `listing` | `Object` | No | Farmer listing for context |
| `offerPricePerQuintal` | `number` | Yes | Buyer's offered price per quintal |
| `mandiPricePerQuintal` | `number` | Yes | Current mandi rate per quintal |
| `quantityQuintals` | `number` | Yes | Quantity being sold |
| `costs.transport` | `number` | No | Transport cost (₹) — applied to both channels |
| `costs.loadingHandling` | `number` | No | Loading/handling charges (₹) |
| `costs.mandiFeePercent` | `number` | No | Mandi fee as % of mandi gross |
| `costs.cessPercent` | `number` | No | Cess as % of mandi gross |
| `costs.commissionPercent` | `number` | No | Commission agent % of mandi gross |

#### Returns

```js
{
  valid: true,
  inputs: { ... },          // echo of all formula inputs
  directSale: {
    grossValue,             // offerPrice × quantity
    itemizedCosts,          // { transport?, loadingHandling? }
    totalCosts,
    estimatedNetProceeds,   // gross − costs
  },
  mandiSale: {
    grossValue,             // mandiPrice × quantity
    itemizedCosts,          // { transport?, loadingHandling?, mandiFee?, cess?, commission? }
    totalCosts,
    estimatedNetProceeds,
  },
  comparison: {
    directMinusMandi,       // positive = direct is better
    betterOption,           // 'Direct Sale' | 'Mandi Sale' | 'Equal'
    commissionSavingsNote,  // null unless commissionPercent was explicitly supplied
    disclaimer,             // always present
  },
  listing,
}
```

#### Commission / Savings Policy

- **`commissionSavingsNote`** is populated **only** when `costs.commissionPercent` is explicitly supplied.
- The note attributes the saving to the specific rate the caller provided.
- **No universal or guaranteed saving is ever claimed.**

---

## Data Contracts

### Farmer Listing

```js
{
  id: 'F001',                      // string, required
  crop: 'Wheat',                   // string, required
  variety: 'HD-2967',              // string, optional (for display)
  quantityQuintals: 50,            // number > 0, required
  harvestDate: '2026-11-15',       // 'YYYY-MM-DD', optional (degrades date score)
  expectedPricePerQuintal: 2200,   // number > 0, required
  district: 'Indore',              // string, required
  state: 'Madhya Pradesh',         // string, required
  grade: 'A',                      // string, optional
  moisture: 12,                    // number, optional
}
```

### Buyer Request

```js
{
  id: 'B001',                    // string, required
  crop: 'Wheat',                 // string, required
  quantityQuintals: 40,          // number > 0, required
  maxPricePerQuintal: 2300,      // number > 0, required
  neededBy: '2026-11-30',        // 'YYYY-MM-DD', optional
  district: 'Indore',            // string, required
  state: 'Madhya Pradesh',       // string, required
}
```

---

## Validation

Both functions validate inputs before processing:

- Empty / missing required fields → error with descriptive message.
- Negative or zero numeric fields → error.
- Non-array inputs to `rankMatches` → error.
- Invalid records are **skipped** (not crash the batch) and collected in `validationErrors`.

---

## Running the Demo

```bash
node src/modules/marketplace/matchingEngine.demo.js
```

---

## Integration Instructions

1. **Import** the functions where needed:
   ```js
   import { rankMatches, calculateDealComparison } from '../modules/marketplace/matchingEngine.js';
   ```

2. **Collect farmer listings and buyer requests** from your data layer / API.

3. **Call `rankMatches`** to get scored, sorted matches:
   ```js
   const { matches, validationErrors } = rankMatches(farmerListings, buyerRequests);
   ```

4. **Call `calculateDealComparison`** when a farmer views a specific offer:
   ```js
   const result = calculateDealComparison({
     listing: selectedListing,
     offerPricePerQuintal: 2300,
     mandiPricePerQuintal: 2250,
     quantityQuintals: 40,
     costs: { transport: 3000, commissionPercent: 2.5 },
   });
   ```

5. **Display `reasons`** array directly in the UI — each string is a complete, human-readable sentence.

6. **Show the `disclaimer`** from `comparison.disclaimer` alongside every deal comparison result.

---

## What This Is / Is Not

| ✅ This module IS | ❌ This module is NOT |
|---|---|
| A rule-based scoring system | Machine learning or AI prediction |
| Deterministic and reproducible | Using any external API or market data |
| Transparent — every score has a reason | Guaranteeing any financial outcome |
| Dependency-free pure JavaScript | Modifying UI, navigation, or shared files |
