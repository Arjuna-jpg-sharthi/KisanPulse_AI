# Government SchemeMatch Module — KisanPulse AI

> **Disclaimer:** KisanPulse AI is **not** an official government service. This module helps farmers discover *potentially relevant* government agricultural schemes. It cannot submit applications, guarantee eligibility, or confirm benefit payments. Always verify information on official government portals.

## Overview

The SchemeMatch module helps Indian farmers:

1. **Browse** a verified catalogue of central government agricultural schemes
2. **Search & filter** by name, keyword, state, and support category
3. **Answer a short questionnaire** to find schemes that may be relevant to their situation
4. **View detailed information** including purpose, benefits, eligibility, documents, and application steps
5. **Bookmark** schemes of interest (persisted in browser local storage)

## Included Schemes

| Scheme | Category | Official Portal |
|--------|----------|-----------------|
| PM-KISAN | Income Support | [pmkisan.gov.in](https://pmkisan.gov.in/) |
| PMFBY | Crop Insurance | [pmfby.gov.in](https://pmfby.gov.in/) |
| Kisan Credit Card (KCC) | Agricultural Credit | [myscheme.gov.in](https://www.myscheme.gov.in/) |
| Soil Health Card Scheme | Soil Health | [soilhealth.dac.gov.in](https://soilhealth.dac.gov.in/) |

## File Structure

```
src/modules/schemes/
├── SchemeModule.jsx     # Main UI component (default export)
├── scheme.css           # All styles (prefixed with "scheme-")
├── schemeData.js        # Verified scheme catalogue + reference data
├── schemeMatcher.js     # Rule-based matching engine (separate from UI)
└── README.md            # This file
```

## How Matching Works

The matcher uses **transparent, rule-based logic** — no black-box ML. For each scheme, it checks:

- **State coverage** — does the scheme operate in the farmer's state?
- **Ownership / cultivation status** — is the farmer's status within the scheme's target group?
- **Landholding category** — does the farm size fall within scope?
- **Support needs** — does the scheme address what the farmer is looking for?

Each match result includes:
- **Match type**: `likely` (strong alignment) or `potential` (partial alignment)
- **Reasons**: human-readable explanations of *why* the scheme was matched
- **Caveats**: things the farmer should verify independently
- A standard disclaimer that final eligibility is determined by the implementing agency

## Farmer Profile Questionnaire

The questionnaire collects only **general, non-sensitive** information:

- State
- Land ownership / cultivation status
- Approximate landholding category
- Primary crop
- Type of support needed

**It does NOT collect** Aadhaar numbers, bank account numbers, or other personal sensitive data.

## Hindi Support

Major labels, field names, scheme purposes, benefits, and key instructions are provided in Hindi alongside English. This is a partial bilingual effort — we do not claim complete Hindi translation.

## Bookmarks & Local Storage

- Bookmarks are stored in `localStorage` under the key `kisanpulse_scheme_bookmarks`.
- They persist across browser refreshes.
- A warning is shown when scheme information has not been recently verified (> 6 months).

## Setup & Running

```bash
# From the project root
npm install
npm run dev
```

The module is imported in `App.jsx` and renders at the root route. No API keys or backend required.

## Known Limitations

1. **Only 4 central schemes** are included in the initial catalogue. State-specific schemes are omitted until their details can be verified from official sources.
2. **Hindi translations are partial.** Not all UI text and scheme details have Hindi equivalents.
3. **Scheme information may become outdated.** The `lastVerified` date indicates when information was last checked. Details older than 6 months trigger a warning.
4. **No real-time data.** The module uses a static catalogue — it does not fetch live data from government APIs.
5. **Matching is indicative, not definitive.** The rule-based matcher cannot verify all eligibility criteria (e.g., income thresholds, exclusion lists). It clearly distinguishes potential matches from confirmed eligibility.
6. **No application submission.** The module links to official portals but cannot submit applications on behalf of the user.

## Official Sources

- [myscheme.gov.in](https://www.myscheme.gov.in/)
- [pmkisan.gov.in](https://pmkisan.gov.in/)
- [pmfby.gov.in](https://pmfby.gov.in/)
- [soilhealth.dac.gov.in](https://soilhealth.dac.gov.in/)
